# Sign language project > 2024-07-12 10:56am
https://universe.roboflow.com/diyorbek-qmkog/sign-language-project-6ixro

Provided by a Roboflow user
License: CC BY 4.0

